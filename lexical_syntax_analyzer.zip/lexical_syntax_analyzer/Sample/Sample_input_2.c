#include<stdio.h>
int check(int x)
{
	int             x;
	printf(");
	scanf("%d",x)
	chr z
	 
}

