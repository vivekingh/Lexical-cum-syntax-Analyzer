#include<stdio.h>
int check(int x)
{
	int y
	
}

